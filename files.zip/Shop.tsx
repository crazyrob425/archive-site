import { useState } from "react";
import { Link, useSearch } from "wouter";
import { trpc } from "@/lib/trpc";
import { Loader2, Search } from "lucide-react";

export default function Shop() {
  const search = useSearch();
  const params = new URLSearchParams(search);
  const [category, setCategory] = useState(params.get("category") || "");
  const [searchTerm, setSearchTerm] = useState("");

  const { data: products, isLoading } = trpc.products.list.useQuery({
    category: category || undefined,
    search: searchTerm || undefined,
  });

  const categories = [
    { value: "", label: "All Products" },
    { value: "lost-hobbies", label: "Lost Hobbies" },
    { value: "industrial-secrets", label: "Industrial Secrets" },
    { value: "technical-manuals", label: "Technical Manuals" },
    { value: "software-collections", label: "Software Collections" },
  ];

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <div className="border-b border-border bg-card/50 py-12">
        <div className="container">
          <h1 className="text-5xl font-bold mb-4">Shop</h1>
          <p className="text-muted-foreground">Browse our collection of rare guides and technical manuals</p>
        </div>
      </div>

      {/* Main Content */}
      <div className="section-spacing">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
            {/* Sidebar */}
            <div className="lg:col-span-1">
              {/* Search */}
              <div className="mb-8">
                <label className="block text-sm font-semibold mb-2">Search</label>
                <div className="relative">
                  <Search className="absolute left-3 top-3 text-muted-foreground" size={18} />
                  <input
                    type="text"
                    placeholder="Search titles..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full pl-10 pr-4 py-2 bg-card border border-border rounded text-foreground placeholder-muted-foreground"
                  />
                </div>
              </div>

              {/* Categories */}
              <div>
                <label className="block text-sm font-semibold mb-4">Category</label>
                <div className="space-y-2">
                  {categories.map((cat) => (
                    <button
                      key={cat.value}
                      onClick={() => setCategory(cat.value)}
                      className={`w-full text-left px-4 py-2 rounded transition-colors ${
                        category === cat.value
                          ? "bg-accent text-accent-foreground font-semibold"
                          : "hover:bg-card text-foreground"
                      }`}
                    >
                      {cat.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Products Grid */}
            <div className="lg:col-span-3">
              {isLoading ? (
                <div className="flex justify-center py-12">
                  <Loader2 className="animate-spin text-accent" size={32} />
                </div>
              ) : products && products.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {products.map((product) => (
                    <Link key={product.id} href={`/product/${product.slug}`} className="card-product group">
                        <div className="aspect-[3/4] overflow-hidden bg-muted">
                          {product.coverImageUrl && (
                            <img
                              src={product.coverImageUrl}
                              alt={product.title}
                              className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                            />
                          )}
                        </div>
                        <div className="p-4">
                          <p className="text-xs text-accent uppercase font-semibold mb-2">{product.category}</p>
                          <h3 className="font-bold line-clamp-2 mb-3">{product.title}</h3>
                          <p className="text-accent font-semibold">${product.price}</p>
                        </div>
                    </Link>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <p className="text-muted-foreground">No products found. Try adjusting your filters.</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
