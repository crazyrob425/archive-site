import { useParams, Link } from "wouter";
import { trpc } from "@/lib/trpc";
import { Loader2, ShoppingCart, ChevronLeft } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export default function ProductDetail() {
  const params = useParams();
  const slug = params.slug as string;
  const [quantity, setQuantity] = useState(1);

  const { data: product, isLoading } = trpc.products.bySlug.useQuery({ slug });
  const addToCart = trpc.cart.add.useMutation({
    onSuccess: () => {
      toast.success("Added to cart!");
      setQuantity(1);
    },
    onError: (err) => {
      toast.error(err.message || "Failed to add to cart");
    },
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="animate-spin text-accent" size={32} />
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen bg-background text-foreground">
        <div className="container py-12">
          <p className="text-muted-foreground">Product not found</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Breadcrumb */}
      <div className="border-b border-border bg-card/50">
        <div className="container py-4">
          <Link href="/shop" className="inline-flex items-center gap-2 text-accent hover:opacity-80">
              <ChevronLeft size={18} />
              Back to Shop
          </Link>
        </div>
      </div>

      {/* Product */}
      <div className="section-spacing">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Image */}
            <div className="aspect-[3/4] bg-card rounded-lg overflow-hidden">
              {product.coverImageUrl && (
                <img
                  src={product.coverImageUrl}
                  alt={product.title}
                  className="w-full h-full object-cover"
                />
              )}
            </div>

            {/* Details */}
            <div>
              <p className="text-accent uppercase text-sm font-semibold mb-4">{product.category}</p>
              <h1 className="text-5xl font-bold mb-6">{product.title}</h1>
              
              <div className="prose-lg mb-8">
                <p className="text-muted-foreground leading-relaxed">{product.description}</p>
              </div>

              {/* Price */}
              <div className="mb-8">
                <p className="text-4xl font-bold text-accent">${product.price}</p>
              </div>

              {/* Add to Cart */}
              <div className="mb-8">
                <div className="flex items-center gap-4 mb-4">
                  <div className="flex items-center border border-border rounded">
                    <button
                      onClick={() => setQuantity(Math.max(1, quantity - 1))}
                      className="px-4 py-2 hover:bg-card transition-colors"
                    >
                      −
                    </button>
                    <input
                      type="number"
                      value={quantity}
                      onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value) || 1))}
                      className="w-12 text-center bg-background border-l border-r border-border py-2"
                    />
                    <button
                      onClick={() => setQuantity(quantity + 1)}
                      className="px-4 py-2 hover:bg-card transition-colors"
                    >
                      +
                    </button>
                  </div>
                </div>
                <button
                  onClick={() => addToCart.mutate({ productId: product.id, quantity })}
                  disabled={addToCart.isPending}
                  className="w-full btn-primary flex items-center justify-center gap-2 disabled:opacity-50"
                >
                  <ShoppingCart size={20} />
                  {addToCart.isPending ? "Adding..." : "Add to Cart"}
                </button>
              </div>

              {/* Trust Signals */}
              <div className="border-t border-border pt-8 space-y-4">
                <div className="flex gap-3">
                  <div className="text-accent">✓</div>
                  <div>
                    <p className="font-semibold">Instant Delivery</p>
                    <p className="text-sm text-muted-foreground">Download immediately after purchase</p>
                  </div>
                </div>
                <div className="flex gap-3">
                  <div className="text-accent">✓</div>
                  <div>
                    <p className="font-semibold">Lifetime Access</p>
                    <p className="text-sm text-muted-foreground">Permanent digital ownership</p>
                  </div>
                </div>
                <div className="flex gap-3">
                  <div className="text-accent">✓</div>
                  <div>
                    <p className="font-semibold">Secure Purchase</p>
                    <p className="text-sm text-muted-foreground">SSL encrypted transactions</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
