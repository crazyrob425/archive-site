import { drizzle } from "drizzle-orm/mysql2";
import { products } from "./drizzle/schema.js";
import * as dotenv from "dotenv";
dotenv.config();

const db = drizzle(process.env.DATABASE_URL);

const seedProducts = [
  {
    title: "The Lost Art of Mechanical Watchmaking",
    slug: "lost-art-mechanical-watchmaking",
    description: "Master the timeless craft of precision watchmaking. This comprehensive guide covers movement assembly, escapement design, and restoration techniques for vintage timepieces. Perfect for horologists and mechanical enthusiasts.",
    category: "lost-hobbies",
    price: "49.99",
    coverImageUrl: "https://d2xsxph8kpxj0f.cloudfront.net/310519663544533152/nECbKg6Xzc4wdMaXszg9TG/book-lost-hobbies-1-4K8heiy9KN3hXRMtuG7Rp5.webp",
    featured: true,
  },
  {
    title: "Forgotten Woodworking Techniques",
    slug: "forgotten-woodworking-techniques",
    description: "Discover hand-tool woodworking methods from the pre-industrial era. Learn traditional joinery, wood selection, and finishing techniques that master craftsmen have used for centuries.",
    category: "lost-hobbies",
    price: "44.99",
    coverImageUrl: "https://d2xsxph8kpxj0f.cloudfront.net/310519663544533152/nECbKg6Xzc4wdMaXszg9TG/book-lost-hobbies-2-L2qSsVqPQ6pAqDYYBVYMVj.webp",
    featured: true,
  },
  {
    title: "Industrial Secrets: Pre-Digital Manufacturing",
    slug: "industrial-secrets-pre-digital",
    description: "Explore the proprietary manufacturing techniques that built industrial empires. Detailed blueprints and specifications for machinery, production workflows, and quality control methods from the golden age of manufacturing.",
    category: "industrial-secrets",
    price: "59.99",
    coverImageUrl: "https://d2xsxph8kpxj0f.cloudfront.net/310519663544533152/nECbKg6Xzc4wdMaXszg9TG/book-industrial-1-jJsFxkKTnTbhpiTY2zncwP.webp",
    featured: true,
  },
  {
    title: "Proprietary Formulations: Chemical Engineering Classics",
    slug: "proprietary-formulations-chemical",
    description: "Unlock rare chemical formulations and synthesis methods from restricted industrial archives. Includes detailed molecular diagrams, reaction pathways, and safety protocols for advanced chemical engineering.",
    category: "industrial-secrets",
    price: "64.99",
    coverImageUrl: "https://d2xsxph8kpxj0f.cloudfront.net/310519663544533152/nECbKg6Xzc4wdMaXszg9TG/book-industrial-2-GmT8oWFtAw7U9k68SkrdMk.webp",
    featured: false,
  },
  {
    title: "Out-of-Print Technical Manual: Vintage Radio Repair",
    slug: "vintage-radio-repair-manual",
    description: "The definitive guide to restoring and repairing classic vacuum tube radios. Complete schematics, component specifications, and troubleshooting procedures for radios from 1920-1960.",
    category: "technical-manuals",
    price: "54.99",
    coverImageUrl: "https://d2xsxph8kpxj0f.cloudfront.net/310519663544533152/nECbKg6Xzc4wdMaXszg9TG/book-technical-1-CgR4snDv5q5o68CKJAp3h8.webp",
    featured: true,
  },
  {
    title: "Obsolete Computer Hardware: Restoration & Recovery",
    slug: "obsolete-computer-hardware",
    description: "A technical deep-dive into vintage computer systems. Learn circuit board repair, component replacement, and data recovery from obsolete storage media. Essential for retro computing enthusiasts.",
    category: "technical-manuals",
    price: "54.99",
    coverImageUrl: "https://d2xsxph8kpxj0f.cloudfront.net/310519663544533152/nECbKg6Xzc4wdMaXszg9TG/book-technical-2-RwsNnryNZGxWtJPC3vGYAb.webp",
    featured: false,
  },
  {
    title: "Secure File Sharing Protocols: Legacy Systems",
    slug: "secure-file-sharing-protocols",
    description: "Master encryption standards and secure data transfer methods used in legacy systems. Comprehensive coverage of cryptographic protocols, authentication mechanisms, and secure architecture design.",
    category: "software-collections",
    price: "69.99",
    coverImageUrl: "https://d2xsxph8kpxj0f.cloudfront.net/310519663544533152/nECbKg6Xzc4wdMaXszg9TG/book-software-1-5fi8Np7z2QnkeXc5P4ZvYh.webp",
    featured: false,
  },
  {
    title: "EBook Management Systems: Advanced Techniques",
    slug: "ebook-management-systems",
    description: "Professional guide to building and managing digital library systems. Covers metadata standards, DRM implementation, distribution platforms, and user interface design for ebook ecosystems.",
    category: "software-collections",
    price: "59.99",
    coverImageUrl: "https://d2xsxph8kpxj0f.cloudfront.net/310519663544533152/nECbKg6Xzc4wdMaXszg9TG/book-software-2-ZtyU8vxngfUNofHi3Ki2CC.webp",
    featured: false,
  },
  {
    title: "Rare Printing Methods: Letterpress & Beyond",
    slug: "rare-printing-methods",
    description: "Explore traditional and rare printing techniques including letterpress, relief printing, and hand-binding. Includes historical context, material sourcing, and step-by-step instruction for artisanal book production.",
    category: "lost-hobbies",
    price: "49.99",
    coverImageUrl: "https://d2xsxph8kpxj0f.cloudfront.net/310519663544533152/nECbKg6Xzc4wdMaXszg9TG/book-niche-1-BQtcYmdRriJVEDrdLmWoje.webp",
    featured: false,
  },
  {
    title: "Archival Preservation: Conservation Masterclass",
    slug: "archival-preservation-conservation",
    description: "The authoritative guide to preserving rare documents, manuscripts, and artifacts. Learn conservation techniques, environmental controls, and restoration methods used by world-class archives.",
    category: "lost-hobbies",
    price: "54.99",
    coverImageUrl: "https://d2xsxph8kpxj0f.cloudfront.net/310519663544533152/nECbKg6Xzc4wdMaXszg9TG/book-niche-2-L9f7Wi9KhhG4Nc7LbqmyYc.webp",
    featured: false,
  },
];

async function seed() {
  try {
    console.log("Seeding products...");
    for (const product of seedProducts) {
      await db.insert(products).values(product);
      console.log(`✓ Created: ${product.title}`);
    }
    console.log("✓ Seed complete!");
    process.exit(0);
  } catch (error) {
    console.error("Seed failed:", error);
    process.exit(1);
  }
}

seed();
